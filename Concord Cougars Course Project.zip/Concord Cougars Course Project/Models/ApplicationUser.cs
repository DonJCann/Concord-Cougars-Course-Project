﻿//Empty Class for the SwimSchool User Entity
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Concord_Cougars_Course_Project.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
